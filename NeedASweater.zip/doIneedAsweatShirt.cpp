#include <iostream>
#include <string>
#include <curl/curl.h>
#include "nlohmann/json.hpp"

using json = nlohmann::json;

// Callback for libcurl to store response in a std::string
size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* output) {
    size_t totalSize = size * nmemb;
    output->append((char*)contents, totalSize);
    return totalSize;
}

// HTTP GET using libcurl
std::string httpGet(const std::string& url) {
    CURL* curl = curl_easy_init();
    std::string response;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "FCC-CIT66-WeatherBot/1.0 (dennis.mohle@fresnocitycollege.edu)");
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        CURLcode res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            std::cerr << "Curl error: " << curl_easy_strerror(res) << std::endl;
        }
        curl_easy_cleanup(curl);
    }
    return response;
}

int main() {
    std::string url = "https://api.weather.gov/gridpoints/HNX/53,100/forecast";
    std::cout << "Fetching forecast for Fresno, CA (NWS HNX/53,100)..." << std::endl;

    // Step 1: Get JSON from NWS
    std::string response = httpGet(url);
    if (response.empty()) {
        std::cerr << "No response from NWS API." << std::endl;
        return 1;
    }

    // Step 2: Parse JSON
    json forecast;
    try {
        forecast = json::parse(response);
    } catch (const std::exception& e) {
        std::cerr << "JSON parse error: " << e.what() << std::endl;
        return 1;
    }

    // Step 3: Extract today's forecast
    auto periods = forecast["properties"]["periods"];
    if (periods.empty()) {
        std::cerr << "No forecast periods found." << std::endl;
        return 1;
    }

    auto today = periods[0];
    int temp = today["temperature"];
    std::string forecastText = today["shortForecast"];
    std::string name = today["name"];

    std::cout << "\n--- Today's Forecast (" << name << ") ---" << std::endl;
    std::cout << "Temperature: " << temp << "°" << today["temperatureUnit"].get<std::string>() << std::endl;
    std::cout << "Conditions: " << forecastText << std::endl;

    // Step 4: Decide if you need a sweatshirt
    std::string advice;
    if (temp < 60) {
        advice = "YES — definitely wear a sweatshirt!";
    } else if (temp < 70) {
        advice = "PROBABLY — bring one, especially if it's breezy.";
    } else {
        advice = "NO — it's warm enough today.";
    }

    std::cout << "\n--- Recommendation ---\n" << advice << std::endl;
    return 0;
}
